# SwiftSpeed-AI

A starter Android app for voice-controlled phone actions.

## Current commands
- Home
- Back
- Recent apps
- Screenshot (Android 11+)
- Scroll up/down

## Build
GitHub Actions is included in `.github/workflows/build-apk.yml`.
After pushing to the `main` branch, GitHub Actions builds the debug APK and stores it as an artifact.

## Important
Phone-control features use Android AccessibilityService and require the user to enable the service manually in Android Settings.
