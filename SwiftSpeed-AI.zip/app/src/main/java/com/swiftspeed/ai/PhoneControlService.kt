package com.swiftspeed.ai

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.os.Handler
import android.os.Looper

class PhoneControlService : AccessibilityService() {

    companion object {
        var instance: PhoneControlService? = null
            private set
    }

    private val handler = Handler(Looper.getMainLooper())

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    override fun onInterrupt() = Unit

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    fun goHome() {
        performGlobalAction(GLOBAL_ACTION_HOME)
    }

    fun goBack() {
        performGlobalAction(GLOBAL_ACTION_BACK)
    }

    fun openRecents() {
        performGlobalAction(GLOBAL_ACTION_RECENTS)
    }

    fun takeScreenshot() {
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
        }
    }

    fun scrollDown() {
        val root = rootInActiveWindow ?: return
        val node = findScrollableNode(root) ?: return
        node.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
    }

    fun scrollUp() {
        val root = rootInActiveWindow ?: return
        val node = findScrollableNode(root) ?: return
        node.performAction(AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)
    }

    fun tap(x: Float, y: Float) {
        if (android.os.Build.VERSION.SDK_INT < 24) return
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 80)
        dispatchGesture(
            GestureDescription.Builder().addStroke(stroke).build(),
            null,
            null
        )
    }

    fun handleCommand(raw: String) {
        val command = raw.lowercase().trim()

        when {
            command.contains("home") || command.contains("होम") ->
                goHome()

            command.contains("back") || command.contains("वापस") ->
                goBack()

            command.contains("recent") || command.contains("recents") ->
                openRecents()

            command.contains("screenshot") || command.contains("स्क्रीनशॉट") ->
                takeScreenshot()

            command.contains("scroll down") || command.contains("नीचे") ->
                scrollDown()

            command.contains("scroll up") || command.contains("ऊपर") ->
                scrollUp()
        }
    }

    private fun findScrollableNode(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isScrollable) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val result = findScrollableNode(child)
            if (result != null) return result
        }
        return null
    }
}
