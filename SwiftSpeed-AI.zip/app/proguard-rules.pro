# SwiftSpeed-AI currently needs no custom ProGuard rules.
